﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Agenda
{
    public interface iajuda
    {
        public string AjudaNovo();
        public string AjudaEdita();
        public string AjudaDeleta();
    }
}
